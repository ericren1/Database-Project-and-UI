# CPS510-Python-UI
## Sec 8, Team 12 - Assignment 9

# Authors

- Dante Romita 
- Eric Ren 
- Tyler Quach 

.exe available to run instead of .py file

Python Libraries:

cx_Oracle
tkinter
